"use client";

import LoginNavbar from "./LoginNavbar";
import LoginCard from "./LoginCard";
import LoginFooter from "./LoginFooter";

export default function LoginPage() {
  return (
    <main className="h-screen bg-[#16240D] flex flex-col overflow-hidden">

      <LoginNavbar />

      <div className="flex-1 flex items-center justify-center px-8 py-5">
        <LoginCard />
      </div>

      <LoginFooter />

    </main>
  );
}