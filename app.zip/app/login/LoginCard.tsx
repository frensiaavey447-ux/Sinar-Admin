"use client";

import Image from "next/image";
import Link from "next/link";
import { Mail, Lock, Eye } from "lucide-react";

export default function LoginCard() {
  return (
    <div className="
        bg-white
        rounded-[28px]
        overflow-hidden
        shadow-xl
        w-[94%]
        max-w-[1500px]
        h-[550px]
        flex
    ">
      {/* ================= LEFT ================= */}

      <div className="w-[43%] flex items-center justify-center bg-white">

        <div className="w-[300px] flex flex-col items-center">

          {/* Logo */}

          <Image
            src="/image/logo2 - Edited2.png"
            alt="SINAR"
            width={150}
            height={150}
            className="object-contain"
          />

          {/* Email */}

          <label className="self-start mt-10 mb-2 text-[#557D3E] text-sm">
            Email or Username
          </label>

          <div className="w-full h-12 bg-[#557D3E] rounded flex items-center px-4 shadow-xl">

            <Mail
              size={20}
              className="text-black"
            />

            <input
              type="text"
              placeholder=""
              className="flex-1 bg-transparent outline-none px-3 text-white placeholder:text-white"
            />

          </div>

          {/* Password */}

          <label className="self-start mt-8 mb-2 text-[#557D3E] text-sm">
            Password
          </label>

          <div className="w-full h-12 bg-[#557D3E] rounded flex items-center px-4 shadow-xl">

            <Lock
              size={20}
              className="text-black"
            />

            <input
              type="password"
              className="flex-1 bg-transparent outline-none px-3 text-white"
            />

            <Eye
              size={18}
              className="cursor-pointer text-black"
            />

          </div>

          {/* Button */}

          <Link
            href="/admin"
            className="mt-14"
          >

            <button
              className="
                w-44
                h-12
                rounded-xl
                bg-[#FFC928]
                hover:bg-yellow-400
                transition
                text-[#29411C]
                text-xl
                font-bold
              "
            >
              Masuk
            </button>

          </Link>

        </div>

      </div>

      {/* ================= RIGHT ================= */}

      <div className="relative w-[57%] overflow-hidden">

        <Image
          src="/image/gedung1.jpeg"
          alt="Gedung"
          fill
          priority
          className="object-cover"
        />

        {/* Gradient */}

        <div className="absolute inset-y-0 left-0 w-40 bg-gradient-to-r from-white via-white/90 to-transparent" />

      </div>

    </div>
  );
}