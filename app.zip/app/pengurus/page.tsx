"use client";

import { useEffect, useState } from "react";

import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import PengurusForm from "../components/PengurusForm";
import PengurusTable from "../components/PengurusTable";

import { supabase } from "../lib/supabase";

export type PengurusType = {
  id: number;
  nama: string;
  jabatan: string;
  foto: string | null;
};

export default function PengurusPage() {
  const [pengurus, setPengurus] = useState<PengurusType[]>([]);
  const [selected, setSelected] = useState<PengurusType | null>(null);
  const [loading, setLoading] = useState(true);

  // ==============================
  // Ambil Data dari Supabase
  // ==============================
  async function getPengurus() {
    setLoading(true);

    const { data, error } = await supabase
      .from("pengurus")
      .select("*")
      .order("id", { ascending: true });

    if (!error && data) {
      setPengurus(data);
    }

    setLoading(false);
  }

  useEffect(() => {
    getPengurus();
  }, []);

  return (
    <main className="min-h-screen bg-[#16240D] flex flex-col">

      <Navbar />

      <section className="flex-1 flex justify-center py-12">

        <div className="w-[92%] max-w-[1300px]">

          <h1 className="text-white text-6xl font-bold mb-10">
            Dasbor Admin
          </h1>

          <div className="grid grid-cols-2 gap-8">

            <PengurusForm
              selected={selected}
              refreshData={getPengurus}
              clearSelected={() => setSelected(null)}
            />

            <PengurusTable
              data={pengurus}
              loading={loading}
              onSelect={setSelected}
            />

          </div>

        </div>

      </section>

      <Footer />

    </main>
  );
}