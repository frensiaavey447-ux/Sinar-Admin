import Navbar from "./Navbar";
import Hero from "./hero";
import PrayerSection from "./PrayerSection";
import EventCard from "./EventCard";
import Footer from "./Footer";

export default function HomePage() {
  return (
<main className="min-h-screen bg-[#16240D] flex flex-col">

  <Navbar />

<div className="flex-1 max-w-7xl mx-auto w-full px-4 pt-12">

    <Hero />

    <section className="grid grid-cols-3 gap-6 mt-4 items-start">
      <div className="col-span-2">
        <PrayerSection />
      </div>

      <EventCard />
    </section>

  </div>

  <Footer />

</main>
  );
}