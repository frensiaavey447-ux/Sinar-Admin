import Image from "next/image";
import { MapPin, ArrowRight } from "lucide-react";

export default function Hero() {
  return (
    <section className="mt-3">

<div
  className="
    bg-white
    rounded-[28px]
    overflow-hidden
    shadow-lg
    grid
    grid-cols-2
    items-center
    h-[330px]
  "
>

        <div className="flex flex-col justify-center px-12">

          <h1 className="text-[24px] font-bold text-[#355728] leading-tight">
            Selamat Datang di SINAR
            <br />
            (Sistem Informasi,
            <br />
            Ngaji dan Administrasi
            <br />
            Rumah Ibadah)
          </h1>

          <div className="flex gap-3 mt-6">

            <MapPin
              size={20}
              className="text-yellow-500 mt-1 shrink-0"
            />

            <p className="text-[15px] leading-7 text-gray-700">

              <span className="font-bold">
                Lokasi :
              </span>{" "}

              Perumahan Jl. Bumi Waringin Indah
              2 No.1 Blok B1,
              Waringinjaya,
              Kedungwaringin,
              Bekasi,
              Jawa Barat 17540,
              Indonesia.

            </p>

          </div>

          <button
            className="
              mt-6
              w-fit
              bg-[#FFC928]
              hover:bg-yellow-400
              px-7
              py-3
              rounded-xl
              font-semibold
              flex
              items-center
              gap-2
            "
          >
            Pelajari lebih lanjut
            <ArrowRight size={18}/>
          </button>

        </div>

<div className="relative h-full">

  <Image
    src="/image/gedung1.jpeg"
    alt="Gedung"
    fill
    priority
    className="object-cover"
  />
    {/* Gradient */}s
  <div
    className="
      absolute
      inset-y-0
      left-0
      w-40
      bg-gradient-to-r
      from-white
      via-white/60
      to-transparent
      pointer-events-none
    "
  />

</div>

      </div>

    </section>
  );
}