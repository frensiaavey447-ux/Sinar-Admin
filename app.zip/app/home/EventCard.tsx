import { Clock3, MapPin } from "lucide-react";

export default function EventCard() {
  return (
    <div>
      <h2 className="text-white text-xl font-semibold mb-5">
        Kegiatan Terdekat
      </h2>

      <div className="bg-white rounded-2xl shadow-md p-4">

        <div className="flex gap-4">

          {/* Kalender */}

          <div className="w-16 h-16 bg-black rounded-xl flex flex-col overflow-hidden flex-shrink-0">

            <div className="h-3 bg-white flex items-center justify-center gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-black"></div>
              <div className="w-1.5 h-1.5 rounded-full bg-black"></div>
            </div>

            <div className="flex-1 flex items-center justify-center">
              <span className="text-white text-2xl font-bold">
                22
              </span>
            </div>

          </div>

          {/* Isi */}

          <div>

            <h3 className="font-bold text-lg leading-tight">
              Sosial Projek
            </h3>

            <h3 className="font-bold text-lg mb-4">
              SINAR
            </h3>

            <div className="flex items-center gap-2 mb-2">

              <Clock3 size={18} />

              <span className="text-sm font-semibold">
                13:00 - selesai
              </span>

            </div>

            <div className="flex items-center gap-2">

              <MapPin size={18} />

              <span className="text-sm font-semibold">
                Auditorium
              </span>

            </div>

          </div>

        </div>

      </div>
    </div>
  );
}