import {
  Sparkles,
  Moon,
  Sunrise,
  Sun,
  CloudSun,
  Sunset,
  CloudMoon,
} from "lucide-react";

const prayers = [
  { name: "Imsak", icon: Sparkles },
  { name: "Subuh", icon: Moon },
  { name: "Terbit", icon: Sunrise },
  { name: "Dzuhur", icon: Sun },
  { name: "Ashar", icon: CloudSun },
  { name: "Magrib", icon: Sunset },
  { name: "Isya", icon: CloudMoon },
];

export default function PrayerSection() {
  return (
    <section>

      <h2 className="text-white text-xl font-bold mb-2">
        Jadwal Shalat
      </h2>

      <div className="grid grid-cols-7 gap-3">

        {prayers.map((item) => {
          const Icon = item.icon;

          return (
            <div
              key={item.name}
              className="
                bg-white
                rounded-2xl
                h-20
                flex
                flex-col
                justify-center
                items-center
            "
            >

              <p className="font-semibold text-base">
                {item.name}
              </p>

             <Icon size={28}/>

            </div>
          );
        })}

      </div>

    </section>
  );
}