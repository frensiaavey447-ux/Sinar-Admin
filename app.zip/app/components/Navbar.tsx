import Image from "next/image";
import Link from "next/link";

export default function Navbar() {
  return (
    <header className="bg-[#557D3E]">
      <div className="max-w-[1500px] mx-auto h-16 px-8 flex items-center justify-between">

        {/* Logo */}
      <div className="flex items-center gap-1">

        <Image
          src="/image/logo22.png"
          alt="Logo Yayasan"
          width={60}
          height={60}
        />

        <Image
          src="/image/logo111.png"
          alt="Logo YPI"
          width={50}
          height={50}
        />

      </div>

        {/* Menu */}
        <nav className="hidden lg:flex items-center gap-8">

          <Link href="/home" className="text-white font-semibold hover:text-yellow-300">
            Home
          </Link>

          <Link href="/profile" className="text-white font-semibold hover:text-yellow-300">
            Profil
          </Link>

          <Link href="/jadwal" className="text-white font-semibold hover:text-yellow-300">
            Jadwal Kegiatan
          </Link>

          <Link href="/pengurus" className="text-white font-semibold hover:text-yellow-300">
            Pengurus
          </Link>

          <Link href="/laporan" className="text-white font-semibold hover:text-yellow-300">
            Laporan Pengeluaran
          </Link>

          <Link href="/inventaris" className="text-white font-semibold hover:text-yellow-300">
            Inventaris
          </Link>

          <Link href="/Data_anak_anak" className="text-white font-semibold hover:text-yellow-300">
            Data Anak-Anak
          </Link>
        </nav>

        {/* Login */}
        <button className="ml-3 bg-[#FFC928] hover:bg-yellow-400 transition px-8 py-2 rounded-full font-bold text-[#29411C]">
            Login
        </button>

      </div>
    </header>
  );
}