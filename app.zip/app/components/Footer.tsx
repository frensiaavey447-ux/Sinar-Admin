import { Mail, Phone } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-[#467235]">

      <div className="max-w-7xl mx-auto px-10 py-2">

        <div className="flex justify-between items-center text-white text-sm">

          <div className="flex items-center gap-2">
            <Mail size={16}/>
            yayasan@ypinurulilmi.sch.id
          </div>

          <div className="flex items-center gap-2">
            <Phone size={16}/>
            Ibu Hanim : 081316853255
          </div>

          <div className="flex items-center gap-2">
            <Phone size={16}/>
            Ibu Ida : 081282307424
          </div>

        </div>

      </div>

      <div className="border-t border-white/20 py-1">

        <p className="text-center text-[11px] text-white">
          Powered by MIS Class 3 - 2025 Group 1
        </p>

      </div>

    </footer>
  );
}